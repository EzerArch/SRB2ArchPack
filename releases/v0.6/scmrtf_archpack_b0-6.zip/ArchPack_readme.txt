***** ArchPack v0.6 Beta *****
File: scmrtf_archpack_b0-6.wad
Author: Ezer'Arch
Version Build: July 17, 2011

Thank you for downloading ArchPack version 0.6 beta. This is a level pack still in development. It contains 7 maps: 4 single-player maps and 3 multi-player maps.

If you prefer, use the batch files to start up SRB2, XSRB2 or SRB2CB (in OpenGL) with ArchPack.

NOTICE: Old time attacks may be incompatible with this version.

If you want more details about this level pack, please refer to the links below:

- ArchPack doc: http://wiki.srb2.org/wiki/User:Ezer'Arch/ArchPack
- Discussion topic: http://mb.srb2.org/showthread.php?t=30971