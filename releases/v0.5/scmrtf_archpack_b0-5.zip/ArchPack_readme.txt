***** ArchPack v0.5 Beta *****
File: scmrtf_archpack_b0-5.wad
Author: Ezer'Arch
Version Build: February 26, 2011

Thank you for downloading ArchPack version 0.5 beta. This is a level pack still in development. It contains 7 maps: 4 single-player maps and 3 multi-player maps.

If you prefer, use the batch files to start up SRB2 or XSRB2 with ArchPack.

If you want more details about this level pack, please refer to the links below:

- ArchPack doc: http://wiki.srb2.org/wiki/User:Ezer'Arch/ArchPack
- Discussion topic: http://mb.srb2.org/showthread.php?t=30971